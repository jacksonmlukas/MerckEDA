# MerckEDA
Data Science Discovery - UC Berkeley

Merck: Benchmark dataset generation for discovery biologics

Malavikha Sudarshan, Jackson Lukas, Jinglan (Cheryl) Liu
